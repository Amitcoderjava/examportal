package com.exam.examservers;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExamserversApplicationTests {

	@Test
	void contextLoads() {
	}

}
