package com.exam.examservers;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExamserversApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExamserversApplication.class, args);
	}

}
